<?php

// ================== One Click Demo Import ==================

// demo files
function millers_import_files() {
    return [
        [
            'import_file_name'           => 'BlogZine',
            'import_file_url'            => get_template_directory_uri() . '/inc/demo/content.xml',
            'import_preview_image_url'   => get_template_directory_uri() . '/inc/demo/preview.jpg',
            'import_customizer_file_url' => get_template_directory_uri() . '/inc/demo/customizer.dat',
            'required_plugins'           => ['elementor', 'header-footer-elementor', 'elementskit-lite', 'fluentform', 'add-to-any'],
            'preview_url'                => 'https://blogzine.wpskilla.com/',
        ]
    ];
}
add_filter('pt-ocdi/import_files', 'millers_import_files');


function millers_after_import_setup() {
    // Set home and blog pages
    $home = get_page_by_title('Home BlogZine');
    $blog = get_page_by_title('Blog BlogZine');
    
    if ($home) {
        update_option('page_on_front', $home->ID);
        update_option('show_on_front', 'page');
    }
    
    if ($blog) {
        update_option('page_for_posts', $blog->ID);
    }

    // Assign menus
    $menu = get_term_by('name', 'Main Menu BlogZine', 'nav_menu');
    if ($menu) {
        set_theme_mod('nav_menu_locations', ['primary' => $menu->term_id]);
    }

    // update options
    $addtoany_options = [
        "position" => "bottom",
        "display_in_posts_on_front_page" => "1",
        "display_in_posts_on_archive_pages" => "-1",
        "display_in_excerpts" => "-1",
        "display_in_posts" => "1",
        "display_in_pages" => "-1",
        "display_in_attachments" => "-1",
        "display_in_feed" => "1",
        "icon_size" => "32",
        "icon_bg" => "original",
        "icon_bg_color" => "#2a2a2a",
        "icon_fg" => "original",
        "icon_fg_color" => "#ffffff",
        "button" => "A2A_SVG_32",
        "button_custom" => "",
        "button_show_count" => "-1",
        "header" => "",
        "additional_js_variables" => "",
        "additional_css" => "",
        "custom_icons" => "-1",
        "custom_icons_url" => "/",
        "custom_icons_type" => "png",
        "custom_icons_width" => "",
        "custom_icons_height" => "",
        "cache" => "-1",
        "display_in_cpt_e-floating-buttons" => "-1",
        "display_in_cpt_elementor_library" => "-1",
        "display_in_cpt_elementskit_content" => "-1",
        "display_in_cpt_elementskit_template" => "-1",
        "display_in_cpt_elementor-hf" => "-1",
        "button_text" => "Share",
        "active_services" => ["facebook", "email", "pinterest", "whatsapp", "google_gmail", "x", "wordpress"],
        "special_facebook_like_options" => ["show_count" => "-1", "verb" => "like"],
        "special_twitter_tweet_options" => ["show_count" => "-1"],
        "special_pinterest_pin_options" => ["show_count" => "-1"],
        "special_pinterest_options" => ["show_count" => "-1"]
    ];
    update_option('addtoany_options', $addtoany_options);

    // Update Elementor Kit Site
    $blogzine_kit = get_page_by_title('BlogZine Kit', OBJECT, 'elementor_library');
    if ($blogzine_kit) {
        update_option('elementor_active_kit', $blogzine_kit->ID);
    }
}
add_action('ocdi/after_import', 'millers_after_import_setup');









