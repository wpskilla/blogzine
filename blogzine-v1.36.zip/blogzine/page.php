<?php get_header(); ?>

<main class="container">
    <?php while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
            </header>

            <?php
            // Parent/Child Page Navigation
            if ($post->post_parent || count(get_pages(['child_of' => get_the_ID()]))) :
            ?>
                <nav class="page-navigation">
                    <ul>
                        <?php
                        if ($post->post_parent) :
                            echo '<li><a href="' . get_permalink($post->post_parent) . '">' . get_the_title($post->post_parent) . '</a></li>';
                        endif;

                        $child_pages = get_pages(['child_of' => get_the_ID()]);
                        foreach ($child_pages as $child) {
                            echo '<li><a href="' . get_permalink($child->ID) . '">' . get_the_title($child->ID) . '</a></li>';
                        }
                        ?>
                    </ul>
                </nav>
            <?php endif; ?>

            <div class="entry-content">
                <?php
                the_content();
                wp_link_pages([
                    'before'      => '<div class="page-links">' . __('Pages:', 'blogzine'),
                    'after'       => '</div>',
                    'link_before' => '<span class="page-number">',
                    'link_after'  => '</span>',
                ]);
                ?>
                <div class="clear"></div>
            </div>

            <?php
            // Show comments only if enabled for the page
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;
            ?>
        </article>
    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
