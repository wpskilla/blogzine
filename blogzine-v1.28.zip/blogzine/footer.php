    <div class="container">
        <footer>
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
        </footer>
    </div>
    <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function () {
            const menuToggle = document.getElementById("miller-menu-toggle");
            const navMenu = document.querySelector("nav ul");
            menuToggle.addEventListener("click", function () {
                navMenu.classList.toggle("menu-open");
            });
        });
    </script>
<?php wp_footer(); ?>
</body>
</html>