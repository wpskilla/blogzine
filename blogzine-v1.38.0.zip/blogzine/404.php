<?php
/**
 * The template for displaying 404 pages (Not Found)
*/

get_header();
?>

<style type="text/css">
.page_404 {padding: 40px 0;background: #fff;max-width: 750px;margin: auto;display: flex;flex-direction: column;gap: 10px;justify-content: center;align-items: center;text-align: center;}
.page_404 h1{font-size:80px !important;}
.page_404 h3{font-size:35px !important;line-height: 45px !important;}
.link_404 {color: #fff !important;padding: 10px 20px;background: #191919;display: inline-block;border-radius: 99rem;}
</style>

<main class="container">
	<section class="page_404">
        <h1 class="text-center">404</h1>
        <h3 class="h2"><?php esc_html_e('Oops! Page Not Found', 'blogzine'); ?></h3>
        <p><?php esc_html_e('The page you are looking for is not available!', 'blogzine'); ?></p>
        <a href="<?php echo esc_url(home_url()); ?>" class="link_404"><?php esc_html_e('Go to Home', 'blogzine'); ?></a>
    </section>
</main>

<?php get_footer(); ?>
