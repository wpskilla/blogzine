=== BlogZine WordPress Theme ===
Contributors: WpSkilla
Theme Name: BlogZine
Theme URI: https://wpskilla.com/blogzine
Author: Usama Shabir
Author URI: https://wpskilla.com/about-us
Requires at least: 5.0
Tested up to: 6.5
Requires PHP: 7.4
Version: 1.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: blog, one-column, custom-background, custom-header, responsive-layout, seo, widget-ready, social-media, accessibility-ready, minimalist, fast-loading

== Description ==
BlogZine is a modern and lightweight WordPress theme designed for bloggers, news websites, and content creators. It is fully responsive, SEO-friendly, and easy to customize.

== Installation ==
1. Download the theme ZIP file.
2. Go to **Appearance > Themes** in your WordPress admin panel.
3. Click **Add New**, then **Upload Theme** and select the ZIP file.
4. Click **Install Now**, then **Activate** the theme.

== Changelog ==
= 1.0 =
* Initial release

== Credits ==
- WordPress (https://wordpress.org/)
- Licensed under GPL v2 or later
