    <div class="container">
        <footer>
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
        </footer>
    </div>
<?php wp_footer(); ?>
</body>
</html>