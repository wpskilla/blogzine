<?php
// Content template for pages
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
    </header>
    <div class="entry-content">
        <?php
            the_content();
            wp_link_pages([
                'before'      => '<div class="page-links">' . __('Pages:', 'blogzine'),
                'after'       => '</div>',
                'link_before' => '<span class="page-number">',
                'link_after'  => '</span>',
            ]);
        ?>
    </div>
</article>